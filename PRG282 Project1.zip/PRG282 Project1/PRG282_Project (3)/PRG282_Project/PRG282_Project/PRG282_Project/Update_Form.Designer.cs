﻿namespace PRG282_Project
{
    partial class Update_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Student_Imgu = new System.Windows.Forms.PictureBox();
            this.update_studentbtn = new System.Windows.Forms.Button();
            this.txt_Resourcesu = new System.Windows.Forms.TextBox();
            this.txt_Genderu = new System.Windows.Forms.TextBox();
            this.txt_ModDescripu = new System.Windows.Forms.TextBox();
            this.txt_Birthdateu = new System.Windows.Forms.TextBox();
            this.txt_ModNameu = new System.Windows.Forms.TextBox();
            this.txt_ModCodeu = new System.Windows.Forms.TextBox();
            this.txt_StdSurnameu = new System.Windows.Forms.TextBox();
            this.txt_Addressu = new System.Windows.Forms.TextBox();
            this.txt_StdNameu = new System.Windows.Forms.TextBox();
            this.txt_Phoneu = new System.Windows.Forms.TextBox();
            this.txt_StudentNou = new System.Windows.Forms.TextBox();
            this.lbl_Resources = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_ModDescrip = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.lbl_ModName = new System.Windows.Forms.Label();
            this.lbl_Picture = new System.Windows.Forms.Label();
            this.lbl_ModCode = new System.Windows.Forms.Label();
            this.lbl_Surname = new System.Windows.Forms.Label();
            this.lbl_Phone = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_StdNo = new System.Windows.Forms.Label();
            this.lbl_CreateStudent = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Student_Imgu)).BeginInit();
            this.SuspendLayout();
            // 
            // Student_Imgu
            // 
            this.Student_Imgu.BackColor = System.Drawing.Color.White;
            this.Student_Imgu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Student_Imgu.Location = new System.Drawing.Point(272, 314);
            this.Student_Imgu.Margin = new System.Windows.Forms.Padding(4);
            this.Student_Imgu.Name = "Student_Imgu";
            this.Student_Imgu.Size = new System.Drawing.Size(190, 92);
            this.Student_Imgu.TabIndex = 31;
            this.Student_Imgu.TabStop = false;
            // 
            // update_studentbtn
            // 
            this.update_studentbtn.BackColor = System.Drawing.Color.Bisque;
            this.update_studentbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.update_studentbtn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_studentbtn.Location = new System.Drawing.Point(433, 459);
            this.update_studentbtn.Margin = new System.Windows.Forms.Padding(4);
            this.update_studentbtn.Name = "update_studentbtn";
            this.update_studentbtn.Size = new System.Drawing.Size(216, 60);
            this.update_studentbtn.TabIndex = 30;
            this.update_studentbtn.Text = "Update Student";
            this.update_studentbtn.UseVisualStyleBackColor = false;
            this.update_studentbtn.Click += new System.EventHandler(this.update_studentbtn_Click);
            // 
            // txt_Resourcesu
            // 
            this.txt_Resourcesu.Location = new System.Drawing.Point(684, 310);
            this.txt_Resourcesu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Resourcesu.Multiline = true;
            this.txt_Resourcesu.Name = "txt_Resourcesu";
            this.txt_Resourcesu.Size = new System.Drawing.Size(183, 24);
            this.txt_Resourcesu.TabIndex = 28;
            // 
            // txt_Genderu
            // 
            this.txt_Genderu.Location = new System.Drawing.Point(273, 272);
            this.txt_Genderu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Genderu.Name = "txt_Genderu";
            this.txt_Genderu.Size = new System.Drawing.Size(189, 22);
            this.txt_Genderu.TabIndex = 27;
            // 
            // txt_ModDescripu
            // 
            this.txt_ModDescripu.Location = new System.Drawing.Point(684, 268);
            this.txt_ModDescripu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ModDescripu.Multiline = true;
            this.txt_ModDescripu.Name = "txt_ModDescripu";
            this.txt_ModDescripu.Size = new System.Drawing.Size(183, 24);
            this.txt_ModDescripu.TabIndex = 26;
            // 
            // txt_Birthdateu
            // 
            this.txt_Birthdateu.Location = new System.Drawing.Point(273, 227);
            this.txt_Birthdateu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Birthdateu.Name = "txt_Birthdateu";
            this.txt_Birthdateu.Size = new System.Drawing.Size(189, 22);
            this.txt_Birthdateu.TabIndex = 25;
            // 
            // txt_ModNameu
            // 
            this.txt_ModNameu.Location = new System.Drawing.Point(684, 227);
            this.txt_ModNameu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ModNameu.Name = "txt_ModNameu";
            this.txt_ModNameu.Size = new System.Drawing.Size(183, 22);
            this.txt_ModNameu.TabIndex = 24;
            // 
            // txt_ModCodeu
            // 
            this.txt_ModCodeu.Location = new System.Drawing.Point(684, 185);
            this.txt_ModCodeu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ModCodeu.Name = "txt_ModCodeu";
            this.txt_ModCodeu.Size = new System.Drawing.Size(183, 22);
            this.txt_ModCodeu.TabIndex = 23;
            // 
            // txt_StdSurnameu
            // 
            this.txt_StdSurnameu.Location = new System.Drawing.Point(272, 185);
            this.txt_StdSurnameu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_StdSurnameu.Name = "txt_StdSurnameu";
            this.txt_StdSurnameu.Size = new System.Drawing.Size(189, 22);
            this.txt_StdSurnameu.TabIndex = 22;
            // 
            // txt_Addressu
            // 
            this.txt_Addressu.Location = new System.Drawing.Point(684, 139);
            this.txt_Addressu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Addressu.Multiline = true;
            this.txt_Addressu.Name = "txt_Addressu";
            this.txt_Addressu.Size = new System.Drawing.Size(183, 24);
            this.txt_Addressu.TabIndex = 21;
            // 
            // txt_StdNameu
            // 
            this.txt_StdNameu.Location = new System.Drawing.Point(272, 143);
            this.txt_StdNameu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_StdNameu.Name = "txt_StdNameu";
            this.txt_StdNameu.Size = new System.Drawing.Size(189, 22);
            this.txt_StdNameu.TabIndex = 20;
            // 
            // txt_Phoneu
            // 
            this.txt_Phoneu.Location = new System.Drawing.Point(684, 99);
            this.txt_Phoneu.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Phoneu.Name = "txt_Phoneu";
            this.txt_Phoneu.Size = new System.Drawing.Size(183, 22);
            this.txt_Phoneu.TabIndex = 19;
            // 
            // txt_StudentNou
            // 
            this.txt_StudentNou.Location = new System.Drawing.Point(272, 102);
            this.txt_StudentNou.Margin = new System.Windows.Forms.Padding(4);
            this.txt_StudentNou.Name = "txt_StudentNou";
            this.txt_StudentNou.Size = new System.Drawing.Size(189, 22);
            this.txt_StudentNou.TabIndex = 29;
            // 
            // lbl_Resources
            // 
            this.lbl_Resources.AutoSize = true;
            this.lbl_Resources.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Resources.Location = new System.Drawing.Point(556, 314);
            this.lbl_Resources.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Resources.Name = "lbl_Resources";
            this.lbl_Resources.Size = new System.Drawing.Size(100, 22);
            this.lbl_Resources.TabIndex = 18;
            this.lbl_Resources.Text = "Resources:";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.Location = new System.Drawing.Point(164, 272);
            this.lbl_Gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(76, 22);
            this.lbl_Gender.TabIndex = 16;
            this.lbl_Gender.Text = "Gender:";
            // 
            // lbl_ModDescrip
            // 
            this.lbl_ModDescrip.AutoSize = true;
            this.lbl_ModDescrip.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModDescrip.Location = new System.Drawing.Point(474, 272);
            this.lbl_ModDescrip.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ModDescrip.Name = "lbl_ModDescrip";
            this.lbl_ModDescrip.Size = new System.Drawing.Size(176, 22);
            this.lbl_ModDescrip.TabIndex = 15;
            this.lbl_ModDescrip.Text = "Module Description:";
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.Location = new System.Drawing.Point(116, 230);
            this.lbl_DOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(122, 22);
            this.lbl_DOB.TabIndex = 14;
            this.lbl_DOB.Text = "Date of Birth:";
            // 
            // lbl_ModName
            // 
            this.lbl_ModName.AutoSize = true;
            this.lbl_ModName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModName.Location = new System.Drawing.Point(525, 227);
            this.lbl_ModName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ModName.Name = "lbl_ModName";
            this.lbl_ModName.Size = new System.Drawing.Size(130, 22);
            this.lbl_ModName.TabIndex = 13;
            this.lbl_ModName.Text = "Module Name:";
            // 
            // lbl_Picture
            // 
            this.lbl_Picture.AutoSize = true;
            this.lbl_Picture.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Picture.Location = new System.Drawing.Point(165, 315);
            this.lbl_Picture.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Picture.Name = "lbl_Picture";
            this.lbl_Picture.Size = new System.Drawing.Size(74, 22);
            this.lbl_Picture.TabIndex = 12;
            this.lbl_Picture.Text = "Picture:";
            // 
            // lbl_ModCode
            // 
            this.lbl_ModCode.AutoSize = true;
            this.lbl_ModCode.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModCode.Location = new System.Drawing.Point(529, 185);
            this.lbl_ModCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ModCode.Name = "lbl_ModCode";
            this.lbl_ModCode.Size = new System.Drawing.Size(125, 22);
            this.lbl_ModCode.TabIndex = 11;
            this.lbl_ModCode.Text = "Module Code:";
            // 
            // lbl_Surname
            // 
            this.lbl_Surname.AutoSize = true;
            this.lbl_Surname.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Surname.Location = new System.Drawing.Point(154, 186);
            this.lbl_Surname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Surname.Name = "lbl_Surname";
            this.lbl_Surname.Size = new System.Drawing.Size(88, 22);
            this.lbl_Surname.TabIndex = 10;
            this.lbl_Surname.Text = "Surname:";
            // 
            // lbl_Phone
            // 
            this.lbl_Phone.AutoSize = true;
            this.lbl_Phone.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Phone.Location = new System.Drawing.Point(594, 102);
            this.lbl_Phone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Phone.Name = "lbl_Phone";
            this.lbl_Phone.Size = new System.Drawing.Size(66, 22);
            this.lbl_Phone.TabIndex = 9;
            this.lbl_Phone.Text = "Phone:";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(576, 140);
            this.lbl_Address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(81, 22);
            this.lbl_Address.TabIndex = 8;
            this.lbl_Address.Text = "Address:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(252, 102);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 16);
            this.label7.TabIndex = 7;
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.Location = new System.Drawing.Point(180, 143);
            this.lbl_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(63, 22);
            this.lbl_Name.TabIndex = 6;
            this.lbl_Name.Text = "Name:";
            // 
            // lbl_StdNo
            // 
            this.lbl_StdNo.AutoSize = true;
            this.lbl_StdNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_StdNo.Location = new System.Drawing.Point(137, 102);
            this.lbl_StdNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_StdNo.Name = "lbl_StdNo";
            this.lbl_StdNo.Size = new System.Drawing.Size(106, 22);
            this.lbl_StdNo.TabIndex = 17;
            this.lbl_StdNo.Text = "Student No:";
            // 
            // lbl_CreateStudent
            // 
            this.lbl_CreateStudent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_CreateStudent.AutoSize = true;
            this.lbl_CreateStudent.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreateStudent.Location = new System.Drawing.Point(357, 10);
            this.lbl_CreateStudent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CreateStudent.Name = "lbl_CreateStudent";
            this.lbl_CreateStudent.Size = new System.Drawing.Size(288, 31);
            this.lbl_CreateStudent.TabIndex = 5;
            this.lbl_CreateStudent.Text = "Adding Student Section";
            // 
            // Update_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(983, 528);
            this.Controls.Add(this.Student_Imgu);
            this.Controls.Add(this.update_studentbtn);
            this.Controls.Add(this.txt_Resourcesu);
            this.Controls.Add(this.txt_Genderu);
            this.Controls.Add(this.txt_ModDescripu);
            this.Controls.Add(this.txt_Birthdateu);
            this.Controls.Add(this.txt_ModNameu);
            this.Controls.Add(this.txt_ModCodeu);
            this.Controls.Add(this.txt_StdSurnameu);
            this.Controls.Add(this.txt_Addressu);
            this.Controls.Add(this.txt_StdNameu);
            this.Controls.Add(this.txt_Phoneu);
            this.Controls.Add(this.txt_StudentNou);
            this.Controls.Add(this.lbl_Resources);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_ModDescrip);
            this.Controls.Add(this.lbl_DOB);
            this.Controls.Add(this.lbl_ModName);
            this.Controls.Add(this.lbl_Picture);
            this.Controls.Add(this.lbl_ModCode);
            this.Controls.Add(this.lbl_Surname);
            this.Controls.Add(this.lbl_Phone);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.lbl_StdNo);
            this.Controls.Add(this.lbl_CreateStudent);
            this.Name = "Update_Form";
            this.Text = "Update_Form";
            ((System.ComponentModel.ISupportInitialize)(this.Student_Imgu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Student_Imgu;
        private System.Windows.Forms.Button update_studentbtn;
        private System.Windows.Forms.TextBox txt_Resourcesu;
        private System.Windows.Forms.TextBox txt_Genderu;
        private System.Windows.Forms.TextBox txt_ModDescripu;
        private System.Windows.Forms.TextBox txt_Birthdateu;
        private System.Windows.Forms.TextBox txt_ModNameu;
        private System.Windows.Forms.TextBox txt_ModCodeu;
        private System.Windows.Forms.TextBox txt_StdSurnameu;
        private System.Windows.Forms.TextBox txt_Addressu;
        private System.Windows.Forms.TextBox txt_StdNameu;
        private System.Windows.Forms.TextBox txt_Phoneu;
        private System.Windows.Forms.TextBox txt_StudentNou;
        private System.Windows.Forms.Label lbl_Resources;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_ModDescrip;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.Label lbl_ModName;
        private System.Windows.Forms.Label lbl_Picture;
        private System.Windows.Forms.Label lbl_ModCode;
        private System.Windows.Forms.Label lbl_Surname;
        private System.Windows.Forms.Label lbl_Phone;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_StdNo;
        private System.Windows.Forms.Label lbl_CreateStudent;
    }
}