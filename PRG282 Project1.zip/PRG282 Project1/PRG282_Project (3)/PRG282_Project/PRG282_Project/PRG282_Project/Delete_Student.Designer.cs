﻿namespace PRG282_Project
{
    partial class Delete_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_DeleteStudent = new System.Windows.Forms.Label();
            this.deletetextbox = new System.Windows.Forms.TextBox();
            this.deletebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_DeleteStudent
            // 
            this.lbl_DeleteStudent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_DeleteStudent.AutoSize = true;
            this.lbl_DeleteStudent.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DeleteStudent.Location = new System.Drawing.Point(397, 23);
            this.lbl_DeleteStudent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DeleteStudent.Name = "lbl_DeleteStudent";
            this.lbl_DeleteStudent.Size = new System.Drawing.Size(124, 31);
            this.lbl_DeleteStudent.TabIndex = 1;
            this.lbl_DeleteStudent.Text = "DELETE";
            // 
            // deletetextbox
            // 
            this.deletetextbox.Location = new System.Drawing.Point(38, 108);
            this.deletetextbox.Name = "deletetextbox";
            this.deletetextbox.Size = new System.Drawing.Size(278, 22);
            this.deletetextbox.TabIndex = 2;
            // 
            // deletebutton
            // 
            this.deletebutton.Location = new System.Drawing.Point(422, 90);
            this.deletebutton.Name = "deletebutton";
            this.deletebutton.Size = new System.Drawing.Size(168, 57);
            this.deletebutton.TabIndex = 3;
            this.deletebutton.Text = "Delete";
            this.deletebutton.UseVisualStyleBackColor = true;
            this.deletebutton.Click += new System.EventHandler(this.deletebutton_Click);
            // 
            // Delete_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(961, 604);
            this.Controls.Add(this.deletebutton);
            this.Controls.Add(this.deletetextbox);
            this.Controls.Add(this.lbl_DeleteStudent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Delete_Student";
            this.Text = "Delete_Student";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_DeleteStudent;
        private System.Windows.Forms.TextBox deletetextbox;
        private System.Windows.Forms.Button deletebutton;
    }
}