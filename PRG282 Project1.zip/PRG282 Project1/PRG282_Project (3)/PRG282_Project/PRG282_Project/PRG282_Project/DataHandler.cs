﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Drawing;

namespace PRG282_Project
{
    public class DataHandler
    {
        //public string connection = "Data Source=DESKTOP-9K6ENBP\\SQLEXPRESS;Initial Catalog=PRG282_PROJECT_DB;Integrated Security=True";
        SqlConnection connection = new SqlConnection (@"Data Source=DESKTOP-H39FGI2; Initial Catalog=Students;Integrated Security=True");

        
        public DataHandler() 
        {

        }
        public DataTable DisplayStudents() 
        {
            string readQuery = @"SELECT * FROM StudentDetails";

            SqlDataAdapter adapter = new SqlDataAdapter(readQuery, connection);

            DataTable dt = new DataTable();

            adapter.Fill(dt);

            return dt;
        }
        public void UpdateDetails(int stdId, string name, string surname, string DoB, string gender, string picture, int phone, string address, string moduleCode, string moduleName, string moduleDescription, string resources)
        {


            try
            {
                string udatequery = $"UPDATE StudentDetails SET Student_NO='{stdId}', Name='{name}', Surname='{surname}', DateOfBirth='{DoB}',Gender='{gender}', Picture='{picture}',Phone='{phone}',Address='{address}',Module_code='{moduleCode}',Module_name='{moduleName}', Module_Description='{moduleDescription}',Resources='{resources}' WHERE Student_NO='{stdId}'";
                SqlCommand cmd = new SqlCommand(udatequery, connection);
                connection.Open();
                cmd.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show($"student {stdId} has been updated");
        }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        public void DeleteDetails(int ST_NO)
        {
            String deletequery = $"DELETE FROM StudentDetails WHERE Student_NO= {ST_NO}";



            try
            {
                SqlCommand cmd = new SqlCommand(deletequery, connection);
                connection.Open();
                cmd.ExecuteNonQuery();
                connection.Close();
                MessageBox.Show($"student {ST_NO} has been deleted");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        public DataTable SearchClient(int StdID)
        {
            try
            {
                string query = $"SELECT * FROM StudentDetails WHERE Student_NO = {StdID}";
                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();
                cmd.ExecuteNonQuery();
                //show the results in a data grid view
                DataTable data = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(data);
                return data;
                //gridView.DataSource = data;
               // connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                DataTable dt = new DataTable();
                return dt;
            }
        }


    }
}
