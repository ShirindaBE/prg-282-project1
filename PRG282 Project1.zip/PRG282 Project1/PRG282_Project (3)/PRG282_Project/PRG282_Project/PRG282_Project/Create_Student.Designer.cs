﻿namespace PRG282_Project
{
    partial class Create_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_CreateStudent = new System.Windows.Forms.Label();
            this.lbl_StdNo = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.lbl_Surname = new System.Windows.Forms.Label();
            this.lbl_Picture = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Phone = new System.Windows.Forms.Label();
            this.lbl_ModCode = new System.Windows.Forms.Label();
            this.lbl_ModName = new System.Windows.Forms.Label();
            this.lbl_ModDescrip = new System.Windows.Forms.Label();
            this.lbl_Resources = new System.Windows.Forms.Label();
            this.txt_StudentNo = new System.Windows.Forms.TextBox();
            this.txt_StdName = new System.Windows.Forms.TextBox();
            this.txt_StdSurname = new System.Windows.Forms.TextBox();
            this.txt_Birthdate = new System.Windows.Forms.TextBox();
            this.txt_Gender = new System.Windows.Forms.TextBox();
            this.txt_Phone = new System.Windows.Forms.TextBox();
            this.txt_Address = new System.Windows.Forms.TextBox();
            this.txt_ModCode = new System.Windows.Forms.TextBox();
            this.txt_ModName = new System.Windows.Forms.TextBox();
            this.txt_ModDescrip = new System.Windows.Forms.TextBox();
            this.txt_Resources = new System.Windows.Forms.TextBox();
            this.btn_AddStudent = new System.Windows.Forms.Button();
            this.Student_Img = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Student_Img)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_CreateStudent
            // 
            this.lbl_CreateStudent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_CreateStudent.AutoSize = true;
            this.lbl_CreateStudent.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CreateStudent.Location = new System.Drawing.Point(304, 64);
            this.lbl_CreateStudent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_CreateStudent.Name = "lbl_CreateStudent";
            this.lbl_CreateStudent.Size = new System.Drawing.Size(288, 31);
            this.lbl_CreateStudent.TabIndex = 0;
            this.lbl_CreateStudent.Text = "Adding Student Section";
            this.lbl_CreateStudent.Click += new System.EventHandler(this.lbl_CreateStudent_Click);
            // 
            // lbl_StdNo
            // 
            this.lbl_StdNo.AutoSize = true;
            this.lbl_StdNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_StdNo.Location = new System.Drawing.Point(84, 156);
            this.lbl_StdNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_StdNo.Name = "lbl_StdNo";
            this.lbl_StdNo.Size = new System.Drawing.Size(106, 22);
            this.lbl_StdNo.TabIndex = 1;
            this.lbl_StdNo.Text = "Student No:";
            this.lbl_StdNo.Click += new System.EventHandler(this.lbl_StdNo_Click);
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.Location = new System.Drawing.Point(127, 197);
            this.lbl_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(63, 22);
            this.lbl_Name.TabIndex = 1;
            this.lbl_Name.Text = "Name:";
            this.lbl_Name.Click += new System.EventHandler(this.lbl_Name_Click);
            // 
            // lbl_Surname
            // 
            this.lbl_Surname.AutoSize = true;
            this.lbl_Surname.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Surname.Location = new System.Drawing.Point(101, 240);
            this.lbl_Surname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Surname.Name = "lbl_Surname";
            this.lbl_Surname.Size = new System.Drawing.Size(88, 22);
            this.lbl_Surname.TabIndex = 1;
            this.lbl_Surname.Text = "Surname:";
            this.lbl_Surname.Click += new System.EventHandler(this.lbl_Surname_Click);
            // 
            // lbl_Picture
            // 
            this.lbl_Picture.AutoSize = true;
            this.lbl_Picture.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Picture.Location = new System.Drawing.Point(112, 369);
            this.lbl_Picture.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Picture.Name = "lbl_Picture";
            this.lbl_Picture.Size = new System.Drawing.Size(74, 22);
            this.lbl_Picture.TabIndex = 1;
            this.lbl_Picture.Text = "Picture:";
            this.lbl_Picture.Click += new System.EventHandler(this.lbl_Picture_Click);
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.Location = new System.Drawing.Point(63, 284);
            this.lbl_DOB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(122, 22);
            this.lbl_DOB.TabIndex = 1;
            this.lbl_DOB.Text = "Date of Birth:";
            this.lbl_DOB.Click += new System.EventHandler(this.lbl_DOB_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(199, 156);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 16);
            this.label7.TabIndex = 1;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.Location = new System.Drawing.Point(111, 326);
            this.lbl_Gender.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(76, 22);
            this.lbl_Gender.TabIndex = 1;
            this.lbl_Gender.Text = "Gender:";
            this.lbl_Gender.Click += new System.EventHandler(this.lbl_Gender_Click);
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(523, 194);
            this.lbl_Address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(81, 22);
            this.lbl_Address.TabIndex = 1;
            this.lbl_Address.Text = "Address:";
            this.lbl_Address.Click += new System.EventHandler(this.lbl_Address_Click);
            // 
            // lbl_Phone
            // 
            this.lbl_Phone.AutoSize = true;
            this.lbl_Phone.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Phone.Location = new System.Drawing.Point(541, 156);
            this.lbl_Phone.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Phone.Name = "lbl_Phone";
            this.lbl_Phone.Size = new System.Drawing.Size(66, 22);
            this.lbl_Phone.TabIndex = 1;
            this.lbl_Phone.Text = "Phone:";
            this.lbl_Phone.Click += new System.EventHandler(this.lbl_Phone_Click);
            // 
            // lbl_ModCode
            // 
            this.lbl_ModCode.AutoSize = true;
            this.lbl_ModCode.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModCode.Location = new System.Drawing.Point(476, 239);
            this.lbl_ModCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ModCode.Name = "lbl_ModCode";
            this.lbl_ModCode.Size = new System.Drawing.Size(125, 22);
            this.lbl_ModCode.TabIndex = 1;
            this.lbl_ModCode.Text = "Module Code:";
            this.lbl_ModCode.Click += new System.EventHandler(this.lbl_ModCode_Click);
            // 
            // lbl_ModName
            // 
            this.lbl_ModName.AutoSize = true;
            this.lbl_ModName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModName.Location = new System.Drawing.Point(472, 281);
            this.lbl_ModName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ModName.Name = "lbl_ModName";
            this.lbl_ModName.Size = new System.Drawing.Size(130, 22);
            this.lbl_ModName.TabIndex = 1;
            this.lbl_ModName.Text = "Module Name:";
            this.lbl_ModName.Click += new System.EventHandler(this.lbl_ModName_Click);
            // 
            // lbl_ModDescrip
            // 
            this.lbl_ModDescrip.AutoSize = true;
            this.lbl_ModDescrip.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ModDescrip.Location = new System.Drawing.Point(421, 326);
            this.lbl_ModDescrip.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ModDescrip.Name = "lbl_ModDescrip";
            this.lbl_ModDescrip.Size = new System.Drawing.Size(176, 22);
            this.lbl_ModDescrip.TabIndex = 1;
            this.lbl_ModDescrip.Text = "Module Description:";
            this.lbl_ModDescrip.Click += new System.EventHandler(this.lbl_ModDescrip_Click);
            // 
            // lbl_Resources
            // 
            this.lbl_Resources.AutoSize = true;
            this.lbl_Resources.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Resources.Location = new System.Drawing.Point(503, 368);
            this.lbl_Resources.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Resources.Name = "lbl_Resources";
            this.lbl_Resources.Size = new System.Drawing.Size(100, 22);
            this.lbl_Resources.TabIndex = 1;
            this.lbl_Resources.Text = "Resources:";
            this.lbl_Resources.Click += new System.EventHandler(this.lbl_Resources_Click);
            // 
            // txt_StudentNo
            // 
            this.txt_StudentNo.Location = new System.Drawing.Point(219, 156);
            this.txt_StudentNo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_StudentNo.Name = "txt_StudentNo";
            this.txt_StudentNo.Size = new System.Drawing.Size(189, 22);
            this.txt_StudentNo.TabIndex = 2;
            this.txt_StudentNo.TextChanged += new System.EventHandler(this.txt_StudentNo_TextChanged);
            // 
            // txt_StdName
            // 
            this.txt_StdName.Location = new System.Drawing.Point(219, 197);
            this.txt_StdName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_StdName.Name = "txt_StdName";
            this.txt_StdName.Size = new System.Drawing.Size(189, 22);
            this.txt_StdName.TabIndex = 2;
            this.txt_StdName.TextChanged += new System.EventHandler(this.txt_StdName_TextChanged);
            // 
            // txt_StdSurname
            // 
            this.txt_StdSurname.Location = new System.Drawing.Point(219, 239);
            this.txt_StdSurname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_StdSurname.Name = "txt_StdSurname";
            this.txt_StdSurname.Size = new System.Drawing.Size(189, 22);
            this.txt_StdSurname.TabIndex = 2;
            this.txt_StdSurname.TextChanged += new System.EventHandler(this.txt_StdSurname_TextChanged);
            // 
            // txt_Birthdate
            // 
            this.txt_Birthdate.Location = new System.Drawing.Point(220, 281);
            this.txt_Birthdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Birthdate.Name = "txt_Birthdate";
            this.txt_Birthdate.Size = new System.Drawing.Size(189, 22);
            this.txt_Birthdate.TabIndex = 2;
            this.txt_Birthdate.TextChanged += new System.EventHandler(this.txt_Birthdate_TextChanged);
            // 
            // txt_Gender
            // 
            this.txt_Gender.Location = new System.Drawing.Point(220, 326);
            this.txt_Gender.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Gender.Name = "txt_Gender";
            this.txt_Gender.Size = new System.Drawing.Size(189, 22);
            this.txt_Gender.TabIndex = 2;
            this.txt_Gender.TextChanged += new System.EventHandler(this.txt_Gender_TextChanged);
            // 
            // txt_Phone
            // 
            this.txt_Phone.Location = new System.Drawing.Point(631, 153);
            this.txt_Phone.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Phone.Name = "txt_Phone";
            this.txt_Phone.Size = new System.Drawing.Size(183, 22);
            this.txt_Phone.TabIndex = 2;
            this.txt_Phone.TextChanged += new System.EventHandler(this.txt_Phone_TextChanged);
            // 
            // txt_Address
            // 
            this.txt_Address.Location = new System.Drawing.Point(631, 193);
            this.txt_Address.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Address.Multiline = true;
            this.txt_Address.Name = "txt_Address";
            this.txt_Address.Size = new System.Drawing.Size(183, 24);
            this.txt_Address.TabIndex = 2;
            this.txt_Address.TextChanged += new System.EventHandler(this.txt_Address_TextChanged);
            // 
            // txt_ModCode
            // 
            this.txt_ModCode.Location = new System.Drawing.Point(631, 239);
            this.txt_ModCode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_ModCode.Name = "txt_ModCode";
            this.txt_ModCode.Size = new System.Drawing.Size(183, 22);
            this.txt_ModCode.TabIndex = 2;
            this.txt_ModCode.TextChanged += new System.EventHandler(this.txt_ModCode_TextChanged);
            // 
            // txt_ModName
            // 
            this.txt_ModName.Location = new System.Drawing.Point(631, 281);
            this.txt_ModName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_ModName.Name = "txt_ModName";
            this.txt_ModName.Size = new System.Drawing.Size(183, 22);
            this.txt_ModName.TabIndex = 2;
            this.txt_ModName.TextChanged += new System.EventHandler(this.txt_ModName_TextChanged);
            // 
            // txt_ModDescrip
            // 
            this.txt_ModDescrip.Location = new System.Drawing.Point(631, 322);
            this.txt_ModDescrip.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_ModDescrip.Multiline = true;
            this.txt_ModDescrip.Name = "txt_ModDescrip";
            this.txt_ModDescrip.Size = new System.Drawing.Size(183, 24);
            this.txt_ModDescrip.TabIndex = 2;
            this.txt_ModDescrip.TextChanged += new System.EventHandler(this.txt_ModDescrip_TextChanged);
            // 
            // txt_Resources
            // 
            this.txt_Resources.Location = new System.Drawing.Point(631, 364);
            this.txt_Resources.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_Resources.Multiline = true;
            this.txt_Resources.Name = "txt_Resources";
            this.txt_Resources.Size = new System.Drawing.Size(183, 24);
            this.txt_Resources.TabIndex = 2;
            this.txt_Resources.TextChanged += new System.EventHandler(this.txt_Resources_TextChanged);
            // 
            // btn_AddStudent
            // 
            this.btn_AddStudent.BackColor = System.Drawing.Color.Bisque;
            this.btn_AddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddStudent.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddStudent.Location = new System.Drawing.Point(380, 513);
            this.btn_AddStudent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_AddStudent.Name = "btn_AddStudent";
            this.btn_AddStudent.Size = new System.Drawing.Size(216, 60);
            this.btn_AddStudent.TabIndex = 3;
            this.btn_AddStudent.Text = "Add Student";
            this.btn_AddStudent.UseVisualStyleBackColor = false;
            this.btn_AddStudent.Click += new System.EventHandler(this.btn_AddStudent_Click);
            // 
            // Student_Img
            // 
            this.Student_Img.BackColor = System.Drawing.Color.White;
            this.Student_Img.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Student_Img.Location = new System.Drawing.Point(219, 368);
            this.Student_Img.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Student_Img.Name = "Student_Img";
            this.Student_Img.Size = new System.Drawing.Size(190, 92);
            this.Student_Img.TabIndex = 4;
            this.Student_Img.TabStop = false;
            this.Student_Img.Click += new System.EventHandler(this.Student_Img_Click);
            // 
            // Create_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(961, 604);
            this.Controls.Add(this.Student_Img);
            this.Controls.Add(this.btn_AddStudent);
            this.Controls.Add(this.txt_Resources);
            this.Controls.Add(this.txt_Gender);
            this.Controls.Add(this.txt_ModDescrip);
            this.Controls.Add(this.txt_Birthdate);
            this.Controls.Add(this.txt_ModName);
            this.Controls.Add(this.txt_ModCode);
            this.Controls.Add(this.txt_StdSurname);
            this.Controls.Add(this.txt_Address);
            this.Controls.Add(this.txt_StdName);
            this.Controls.Add(this.txt_Phone);
            this.Controls.Add(this.txt_StudentNo);
            this.Controls.Add(this.lbl_Resources);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_ModDescrip);
            this.Controls.Add(this.lbl_DOB);
            this.Controls.Add(this.lbl_ModName);
            this.Controls.Add(this.lbl_Picture);
            this.Controls.Add(this.lbl_ModCode);
            this.Controls.Add(this.lbl_Surname);
            this.Controls.Add(this.lbl_Phone);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_Name);
            this.Controls.Add(this.lbl_StdNo);
            this.Controls.Add(this.lbl_CreateStudent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Create_Student";
            this.Text = "Create_Student";
            ((System.ComponentModel.ISupportInitialize)(this.Student_Img)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_CreateStudent;
        private System.Windows.Forms.Label lbl_StdNo;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.Label lbl_Surname;
        private System.Windows.Forms.Label lbl_Picture;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Phone;
        private System.Windows.Forms.Label lbl_ModCode;
        private System.Windows.Forms.Label lbl_ModName;
        private System.Windows.Forms.Label lbl_ModDescrip;
        private System.Windows.Forms.Label lbl_Resources;
        private System.Windows.Forms.TextBox txt_StudentNo;
        private System.Windows.Forms.TextBox txt_StdName;
        private System.Windows.Forms.TextBox txt_StdSurname;
        private System.Windows.Forms.TextBox txt_Birthdate;
        private System.Windows.Forms.TextBox txt_Gender;
        private System.Windows.Forms.TextBox txt_Phone;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.TextBox txt_ModCode;
        private System.Windows.Forms.TextBox txt_ModName;
        private System.Windows.Forms.TextBox txt_ModDescrip;
        private System.Windows.Forms.TextBox txt_Resources;
        private System.Windows.Forms.Button btn_AddStudent;
        private System.Windows.Forms.PictureBox Student_Img;
    }
}