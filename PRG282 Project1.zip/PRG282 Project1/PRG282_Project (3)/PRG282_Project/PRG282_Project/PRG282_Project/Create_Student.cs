﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PRG282_Project
{
    public partial class Create_Student : Form
    {
        public SqlConnection con;
        public Create_Student()
        {    
            con = new SqlConnection("Data Source=DESKTOP-H39FGI2;Initial Catalog=Students;Integrated Security=True");
            InitializeComponent();
        }

        private void btn_AddStudent_Click(object sender, EventArgs e)
        {
            string insertQuery = @"INSERT INTO StudentDetails(Student_NO, Name, Surname,DateOfBirth, Gender,Picture ,Phone, " +
                "Address, Module_code, Module_name, Module_description,Resources) VALUES('"+ txt_StudentNo.Text + "','" +
                txt_StdName.Text + "','" + txt_StdSurname.Text + "','" +txt_Birthdate.Text + "','" +txt_Gender.Text+ "','" +Student_Img + "','" + txt_Phone.Text + "','" + txt_Address.Text + "','" + txt_ModCode.Text + "','" + 
                txt_ModName.Text + "','" + txt_ModDescrip.Text + "','" + txt_Resources.Text + "')";

            try
            {
                con.Open();

                SqlCommand command = new SqlCommand(insertQuery, con);
                command.ExecuteNonQuery();

                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
                MessageBox.Show("The data could not be inserted into the database!", "Please try again.", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Student_Img_Click(object sender, EventArgs e)
        {

        }

        private void txt_Resources_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Gender_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_ModDescrip_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Birthdate_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_ModName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_ModCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_StdSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Address_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_StdName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_Phone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_StudentNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_Resources_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Gender_Click(object sender, EventArgs e)
        {

        }

        private void lbl_ModDescrip_Click(object sender, EventArgs e)
        {

        }

        private void lbl_DOB_Click(object sender, EventArgs e)
        {

        }

        private void lbl_ModName_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Picture_Click(object sender, EventArgs e)
        {

        }

        private void lbl_ModCode_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Surname_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Phone_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Address_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Name_Click(object sender, EventArgs e)
        {

        }

        private void lbl_StdNo_Click(object sender, EventArgs e)
        {

        }

        private void lbl_CreateStudent_Click(object sender, EventArgs e)
        {

        }
    }
}
