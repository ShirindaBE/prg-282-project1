﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
namespace PRG282_Project
{
   
    public partial class Search_Students : Form
    {
        public Search_Students()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataHandler dt = new DataHandler();
            try 
            {
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = dt.SearchClient(int.Parse(txtsearch.Text));
            
            }
            catch  
            {
                MessageBox.Show("please enter proper integer not a string");
            }


        }
    }
}
